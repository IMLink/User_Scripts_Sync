// ==UserScript==
// @name CL1024改进版
// @namespace CL1024
// @version 2020.4.5.1
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @homepageURL https://greasyfork.org/zh-CN/scripts/1983-cl1024
// @copyright 2012-2015 rose20.99.c@gmail.com
// @include http://*
// @include https://*
// @grant  GM_addStyle
// @2018.08.11 新增链接跳转到viidii的问题
// @2018.06.21 新增图片链接跳转到viidii的问题
// @2019.06.20 修复图片链接跳转到viidii的问题
// @2020.02.18 修复图片显示问题
// @2020.04.05 解决“网页元素被去广告插件破坏”的问题

// 原作者信息
// @author      rose1988c
// @code        https://github.com/rose1988c/Caoliu.plug
// @blog        http://cl.aacc.in
// @date        2012.11.15
// @modified    2012.11.15  磁链接转化
// @modified    2012.11.28  去广告
// @modified    2012.12.23  帖子按楼跳转页面，方便用户在<求片求助贴>找片
// @modified    2013.01.05  按楼跳转页面,并'定位指定楼层'
// @modified    2013.01.17  隐藏1024的回复
// @modified    2013.03.11  今日帖子高亮 - 列表标题左边“.::”将改为“Today”
// @modified    2013.03.12  [暂失效]新增快捷键 - 打开帖子， __J__为下一个回复，__K__为上一个回复，点__.__返回顶部
// @modified    2013.03.18  修复bug - 回复后滚动条跳到顶部
// @1.1.4   2014.01.03  更新 - vivi跳转更新
// @1.1.5   2014-01-03  更新 - 修复点击[显示]无效
// @1.1.6   2014-01-03  BUG - 排除迅雷离线页面加载脚本。感谢@文科
// @1.1.7   2014-01-03  更新 - 超高清、大图根据屏幕尺寸缩放到适合屏幕大小
// @1.1.7   2014-01-03  BUG - 修复点击[显示]无效
// @1.1.8   2014-01-04  更新 - 新增点击下载种子
// @1.1.9   2014-1-14   增加统计
// @1.2.2   2014-1-14   更新匹配问题
// @1.2.3   2014-2-21   更新Chrome 插件失效问题。CL闹哪样？非得加载http://69.175.44.45:88/style.css?v=1.1 卡死了。
// @1.2.4   2014-2-21   防止69.175.44.45:88 css加载失败
// @1.2.5   2014-6-2    防止jquery加载失败
// @1.2.6   2014-6-2    userscripts加载失败
// @1.2.8   2014-6-17   修复偷懒造成的无法访问，js过大
// @1.2.9   2014-7-7    修复偷懒匹配网站问题
// @1.3.0   2015-9-6    修复反馈的bug，匹配网站、和第二页黑屏，增加chrome插件提示
// @1.3.1   2015-9-6    修改chrome发布网址
// @1.3.2   2015-9-10   去掉google统计
// @1.3.3   2017-1-19   fix
// ==/UserScript==
