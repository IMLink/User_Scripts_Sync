// ==UserScript==
// @name        恢复色彩-移除默哀网站全局灰色
// @namespace   https://greasyfork.org/zh-CN/scripts/455667-恢复色彩-移除默哀网站全局灰色
// @match       *://*/*
// @grant       none
// @version     1.3
// @author      lqs1848
// @description 2022/11/30 17:08:29
// @supportURL  https://blog.lqs1848.top/
// ==/UserScript==


(function() {
    'use strict';
    document.body.style.filter='none';
    document.getElementsByTagName('html')[0].style.filter = 'none';
    var arr = document.getElementsByTagName('div');
    for(var i=0;i<arr.length;i++){
      arr[i].style.filter='none';
    }
})();